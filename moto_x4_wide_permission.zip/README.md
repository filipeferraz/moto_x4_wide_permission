Adds 16mp mode on all camera apps for front camera, and 2268p vidio mode for back camera. increased audio bitrate and hevc support. 
to use 2268p you need freedcam app available on playstore. 